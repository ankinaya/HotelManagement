package com.hotelManagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hotelManagement.models.Admin;
import com.hotelManagement.models.Hotel;
import com.hotelManagement.models.Manager;
import com.hotelManagement.service.IAdminService;
import com.hotelManagement.service.IHotelService;
import com.hotelManagement.service.IManagerService;
import com.hotelManagement.service.ManagerService;

@Controller
public class hotelController {

	@Autowired
	IHotelService hotelService;

	@Autowired
	IAdminService adminService;

	@Autowired
	IManagerService managerService;

	@PostMapping("/create")
	public void Create() {
		Admin a = new Admin("superadmin", "superadmin", "SUPERADMIN");
		adminService.create(a);

	}

	@RequestMapping("/")
	public String login(@ModelAttribute("admin") Admin admin) {
//		System.out.println("hello.................");
		return "login";
	}

	@RequestMapping("/index")
	public String index(@ModelAttribute("admin") Admin admin, Model m) {
		Admin a = adminService.searchById(admin.getUsername());
		// System.out.println("Hiii"+em);
		if (a != null) {
			if (admin.getPassword().equals(a.getPassword())) {
//				System.out.println(admin.getPassword());
//				session.setAttribute("empId", em.getEmplId());
				if (a.getRole().equalsIgnoreCase("SUPERADMIN")) {
					return "sMenu";
				}
				return "hMenu";
			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "login";
			}

		} else {
			m.addAttribute("msg", "User doesn't Exist.");
			return "login";
		}

	}

	// SUPER ADMIN MENU
	// ADD HOTEL

	@RequestMapping(method = RequestMethod.GET, path = "/addHotel")

	public String addHotel(@ModelAttribute("admin") Admin admin, @ModelAttribute("hotel") Hotel hotel, Model model) {

		return "addHotelform";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/addHoteDetails")

	public String addHotelDetails(@ModelAttribute("hotel") Hotel hotel, @ModelAttribute("manager") Manager manager,
			Model model, HttpSession session) {
//    	hotelService.createHotel(hotel);
		session.setAttribute("hotelId", hotel.getHotelId());
		session.setAttribute("hotel", hotel);
		return "addManagerform";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/addManagerDetails")

	public String addManagerDetails(@ModelAttribute("admin") Admin admin, @ModelAttribute("manager") Manager manager,
			Model model, HttpSession session) {
//       	hotelService.createHotel(hotel);

		manager.setManagerId(session.getAttribute("hotelId").toString());
		session.setAttribute("manager", manager);
		return "setHotelAuthentication";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/setHotelPassword")

	public String addHotelFinal(@ModelAttribute("admin") Admin admin, Model model, HttpSession session) {
//       	hotelService.createHotel(hotel);

		admin.setUsername(session.getAttribute("hotelId").toString());
		admin.setRole("Admin");
		Hotel hotel1 = (Hotel) session.getAttribute("hotel");
		System.out.println((Hotel) session.getAttribute("hotel"));
		hotelService.createHotel(hotel1);
		Manager manager1 = (Manager) session.getAttribute("manager");
		managerService.createManager(manager1);
		adminService.create(admin);
		model.addAttribute("msg", "Added Successfully!!");
		return "sMenu";
	}

	// VIEW HOTEL
	@RequestMapping("/viewHotels")
	public String viewHotel() {
		return "viewHotel";
	}

	// DELETE HOTEL
	@RequestMapping("/deleteHotel")
	public String deleteHotel() {
		return "deleteHotel";
	}

	// RENEW HOTEL SUBSCRIPTION
	@RequestMapping("/renewalHotel")
	public String renewHotel() {
		return "renewHotel";
	}

}
