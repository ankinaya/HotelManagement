package com.hotelManagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelManagement.models.Hotel;
import com.hotelManagement.repository.HotelRepository;

@Service
public class HotelService implements IHotelService {
	
	@Autowired
	HotelRepository hotelRepository;

	public HotelService() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * @Override public void create(Hotel h) { // TODO Auto-generated method stub //
	 * if(hotelRepository.findById(h.getHotelId()).equals(null))
	 * hotelRepository.save(h); }
	 */

	@Override
	public void createHotel(Hotel h) {
		// TODO Auto-generated method stub
//	if(hotelRepository.findById(h.getHotelId()).equals(null))
		hotelRepository.save(h);
	}


	
	

}
