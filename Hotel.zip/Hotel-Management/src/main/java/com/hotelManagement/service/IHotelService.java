package com.hotelManagement.service;

import com.hotelManagement.models.Hotel;

public interface IHotelService {
public void createHotel(Hotel h);
}
