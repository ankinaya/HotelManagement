package com.hotelManagement.service;


import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

import com.hotelManagement.models.Admin;
import com.hotelManagement.models.Hotel;

public interface IAdminService {
	public Admin searchById(String id);
	public  Admin create(Admin a) ;
	/*
	 * public Admin addHotel(@Valid Hotel hotel, BindingResult result); public Admin
	 * updateHotel(Hotel h); public Admin deleteHotel(int id); public List<Hotel>
	 * getAllHotel();
	 */
	
	
}
