package com.hotelManagement.repository;

import javax.validation.Valid;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.hotelManagement.models.Admin;
import com.hotelManagement.models.Hotel;

@Repository
public interface AdminRepository extends MongoRepository<Admin, String> {
	
	

	Admin insert(@Valid Hotel hotel);
	

}
