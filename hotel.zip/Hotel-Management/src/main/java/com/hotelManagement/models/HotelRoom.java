package com.hotelManagement.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "room")
public class HotelRoom {
	
	
	@Id
	int roomId;
	String hotelId;
	String roomType;
	String roomCategory;
	boolean roomAvailability;
	
	
	
	public HotelRoom() {
		super();
		// TODO Auto-generated constructor stub
	}



	public HotelRoom(int roomId, String hotelId, String roomType, String roomCategory, boolean roomAvailability) {
		super();
		this.roomId = roomId;
		this.hotelId = hotelId;
		this.roomType = roomType;
		this.roomCategory = roomCategory;
		this.roomAvailability = roomAvailability;
	}



	public int getRoomId() {
		return roomId;
	}



	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}



	public String getHotelId() {
		return hotelId;
	}



	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}



	public String getRoomType() {
		return roomType;
	}



	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}



	public String getRoomCategory() {
		return roomCategory;
	}



	public void setRoomCategory(String roomCategory) {
		this.roomCategory = roomCategory;
	}



	public boolean isRoomAvailability() {
		return roomAvailability;
	}



	public void setRoomAvailability(boolean roomAvailability) {
		this.roomAvailability = roomAvailability;
	}
	
	


}
