package com.hotelManagement.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.hotelManagement.models.HotelRoom;

@Repository
public interface HotelRoomRepository extends MongoRepository<HotelRoom, Integer>{

}
