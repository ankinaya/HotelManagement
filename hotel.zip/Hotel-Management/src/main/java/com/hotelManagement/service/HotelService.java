package com.hotelManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelManagement.models.Hotel;
import com.hotelManagement.models.HotelRoom;
import com.hotelManagement.repository.HotelRepository;
import com.hotelManagement.repository.HotelRoomRepository;

@Service
public class HotelService implements IHotelService {

	@Autowired
	HotelRepository hotelRepository;
	
	@Autowired
	HotelRoomRepository hotelRoomRepository;

	public HotelService() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * @Override public void create(Hotel h) { // TODO Auto-generated method stub //
	 * if(hotelRepository.findById(h.getHotelId()).equals(null))
	 * hotelRepository.save(h); }
	 */

	@Override
	public void createHotel(Hotel h) {
		// TODO Auto-generated method stub
//	if(hotelRepository.findById(h.getHotelId()).equals(null))
		hotelRepository.save(h);
	}

	@Override
	public List<Hotel> viewHotel() {
		// TODO Auto-generated method stub
		return hotelRepository.findAll();
	}
	

	@Override
	public void deleteByHotelId(String hotelId) {
		 hotelRepository.deleteByHotelId(hotelId);
		
	}

	@Override
	public void createHotelRoom(HotelRoom r) {
		// TODO Auto-generated method stub
		hotelRoomRepository.save(r);
	}

	@Override
	public List<HotelRoom> viewHotelRooms() {
		// TODO Auto-generated method stub
		return hotelRoomRepository.findAll();
	}

	@Override
	public void deleteByRoomId(int roomId) {
		// TODO Auto-generated method stub
		hotelRoomRepository.deleteById(roomId);
	}


}
