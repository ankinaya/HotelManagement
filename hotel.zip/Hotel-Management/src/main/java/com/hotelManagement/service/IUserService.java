package com.hotelManagement.service;

import com.hotelManagement.models.User;

public interface IUserService {
	public void create(User user);
}
