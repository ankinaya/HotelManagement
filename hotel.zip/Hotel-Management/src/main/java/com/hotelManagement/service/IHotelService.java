package com.hotelManagement.service;

import java.util.List;

import org.springframework.data.mongodb.repository.Query;

import com.hotelManagement.models.Hotel;
import com.hotelManagement.models.HotelRoom;

public interface IHotelService {
public void createHotel(Hotel h);
public List<Hotel> viewHotel();
public void deleteByHotelId(String hotelId);
public void createHotelRoom(HotelRoom r);
public List<HotelRoom> viewHotelRooms();
public void deleteByRoomId(int roomId);
}
