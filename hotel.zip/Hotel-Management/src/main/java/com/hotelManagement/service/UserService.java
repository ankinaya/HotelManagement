package com.hotelManagement.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelManagement.models.User;
import com.hotelManagement.repository.UserRepository;

@Service
public class UserService implements IUserService {

	@Autowired
	UserRepository userRepository;

	public UserService() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void create(User user) {
		userRepository.save(user);
	}

}
