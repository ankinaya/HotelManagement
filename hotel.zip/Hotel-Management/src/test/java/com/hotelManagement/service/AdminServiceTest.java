package com.hotelManagement.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdminServiceTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
